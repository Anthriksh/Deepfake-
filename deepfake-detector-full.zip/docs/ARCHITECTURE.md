# Project Architecture

```
deepfake-detector-full/
│── frontend/   # React + Tailwind frontend
│── backend/    # FastAPI backend
│── docs/       # Documentation
```
